CREATE VIEW v3 AS
  SELECT
    `db_book`.`t_book`.`bookName`         AS `b`,
    `db_book`.`t_booktype`.`bookTypeName` AS `t`
  FROM `db_book`.`t_book`
    JOIN `db_book`.`t_booktype`
  WHERE (`db_book`.`t_book`.`bookTypeId` = `db_book`.`t_booktype`.`id`);
