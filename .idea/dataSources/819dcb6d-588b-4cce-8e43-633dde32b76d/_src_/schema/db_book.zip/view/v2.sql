CREATE VIEW v2 AS
  SELECT
    `db_book`.`t_book`.`bookName` AS `b`,
    `db_book`.`t_book`.`price`    AS `p`
  FROM `db_book`.`t_book`
  WHERE (`db_book`.`t_book`.`price` > 80);
