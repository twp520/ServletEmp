CREATE VIEW hight_price_book AS
  SELECT
    `db_book`.`t_book`.`id`         AS `id`,
    `db_book`.`t_book`.`bookName`   AS `bookName`,
    `db_book`.`t_book`.`price`      AS `price`,
    `db_book`.`t_book`.`author`     AS `author`,
    `db_book`.`t_book`.`bookTypeId` AS `bookTypeId`
  FROM `db_book`.`t_book`;
