CREATE TRIGGER tig_book
AFTER INSERT ON t_book
FOR EACH ROW
  UPDATE t_booktype SET bookNum=bookNum+1 WHERE new.bookTypeId = t_booktype.`id`;
