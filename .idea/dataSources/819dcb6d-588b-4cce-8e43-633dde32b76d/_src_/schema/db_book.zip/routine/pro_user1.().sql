CREATE PROCEDURE pro_user1()
  begin
	  declare a,b varchar(10);
	  insert into t_user value(null,a,b);
	end;
