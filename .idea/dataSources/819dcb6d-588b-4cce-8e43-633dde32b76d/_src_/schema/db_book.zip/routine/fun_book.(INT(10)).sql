CREATE FUNCTION fun_book(bookId INT(10))
  RETURNS VARCHAR(20)
  CHARSET utf8
  begin
		return (select bookName from t_book where id=bookId);
	end;
