CREATE PROCEDURE pro_user3()
  begin
	  declare a,b varchar(20);
	  set a='java1234',b='9999';
	  insert into t_user value(34,a,b);
	end;
