CREATE PROCEDURE pro_test2(IN id INT(10))
  begin
	  select count(*) into @num from t_test tt where tt.id=id; 
	  case @num
	  when 0 then insert into t_test value(null,'方世玉');	
	  when 1 then update t_test tt set test='黄飞鸿' where tt.id=id;
	  else insert into t_test value(null,'李小龙');
	  end case ;
	end;
