CREATE PROCEDURE pro_test3(IN total INT(10))
  begin
	  aaa:loop
	    insert into t_test value(null,'ccc');
	    set total= total-1;
	    if total=0 then leave aaa;
	    end if ;
	  end loop aaa ;
	end;
