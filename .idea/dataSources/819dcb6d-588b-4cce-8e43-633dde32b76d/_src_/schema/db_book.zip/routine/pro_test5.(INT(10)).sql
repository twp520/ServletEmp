CREATE PROCEDURE pro_test5(IN total INT(10))
  begin
	  repeat 	
	   set total=total-1;
	   insert into t_test value(null,'ddd');
	   until total=0 
	  end repeat;	
	end;
