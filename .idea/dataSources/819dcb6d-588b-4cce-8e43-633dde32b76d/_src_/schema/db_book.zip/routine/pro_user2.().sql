CREATE PROCEDURE pro_user2()
  begin
	 declare a,b varchar(20);
	 select userName2,pwd2 into a,b from t_user2 where id=1;
	 insert into t_user value(11,a,b);
	end;
