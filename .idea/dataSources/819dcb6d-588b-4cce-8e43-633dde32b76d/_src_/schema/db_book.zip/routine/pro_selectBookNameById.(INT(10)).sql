CREATE PROCEDURE pro_selectBookNameById(IN id INT(10), OUT bookName VARCHAR(20))
  begin 
	  select t_book.`bookName` into bookName from t_book where t_book.`id`=id;
	end;
