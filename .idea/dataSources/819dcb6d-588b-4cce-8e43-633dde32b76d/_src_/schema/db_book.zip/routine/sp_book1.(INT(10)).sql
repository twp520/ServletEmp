CREATE PROCEDURE sp_book1(IN bt INT(10), OUT book_num INT(10))
  begin
	  select count(*) from t_book where t_book.bookTypeId=bt;
	  insert into t_book value(null,'test_book',123.09,'test_author',bt);
	end;
