CREATE PROCEDURE pro_test6(IN total INT(10))
  begin
	  while total>0 do
	  INSERT INTO t_test VALUE(NULL,'eee');
	  set total = total-1;
	  end while;
	end;
