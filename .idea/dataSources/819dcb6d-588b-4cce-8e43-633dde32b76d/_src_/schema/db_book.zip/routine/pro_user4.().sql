CREATE PROCEDURE pro_user4()
  begin
	  declare a,b varchar(20);
	  declare cur_t_user cursor for select userName2,pwd2 from t_user2;
	  open cur_t_user;
	  fetch cur_t_user into a,b;
	  insert into t_user value(124,a,b);
	end;
