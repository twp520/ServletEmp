CREATE PROCEDURE sp_book(IN bt INT(10), OUT book_num INT(10))
  begin
	  select count(*) from t_book where t_book.bookTypeId=bt;
	end;
