CREATE PROCEDURE pro_test1(IN id INT(10))
  begin 
	  select count(*) into @num from t_test where t_test.`id`=id;
	  if @num>0 then update t_test set test='田伟平' where t_test.`id`=id;
	  else insert into t_test value (null,'杨依舟'); 
	  end if ;
	end;
